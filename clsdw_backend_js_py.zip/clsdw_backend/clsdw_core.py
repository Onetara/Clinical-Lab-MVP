"""
clsdw_core.py — Clinical Lab & Sample Data Workflows: Python Logic Backend
Mirrors app.js (Stacy Toriola / Anthony O.) deterministically.

All business rules replicated:
  - CRC32 (IEEE 802.3, identical polynomial to JS version)
  - Mulberry32 PRNG for deterministic reconciliation
  - Clinical validation gates (E001–E010)
  - Audit trail with per-entry checksums
  - Processing & category assignment
  - Reconciliation with SLA enforcement
"""

from __future__ import annotations

import json
import re
import time
import math
import random
import hashlib
import csv
import io
import copy
from datetime import datetime, timezone
from typing import Any, Optional
from xml.etree import ElementTree as ET
from xml.etree.ElementTree import ParseError as XmlParseError


# ---------------------------------------------------------------------------
# CRC32 (IEEE 802.3) — matches JS implementation exactly
# ---------------------------------------------------------------------------

def _build_crc32_table() -> list[int]:
    table = []
    for n in range(256):
        c = n
        for _ in range(8):
            if c & 1:
                c = 0xEDB88320 ^ (c >> 1)
            else:
                c = c >> 1
        table.append(c & 0xFFFFFFFF)
    return table


_CRC32_TABLE = _build_crc32_table()


def crc32(s: str) -> int:
    """Compute CRC32 matching the JS IEEE 802.3 implementation."""
    crc = 0xFFFFFFFF
    for ch in s.encode("utf-8"):
        crc = (crc >> 8) ^ _CRC32_TABLE[(crc ^ ch) & 0xFF]
    return (crc ^ 0xFFFFFFFF) & 0xFFFFFFFF


def crc32_hex(s: str) -> str:
    return format(crc32(s), "08x")


# ---------------------------------------------------------------------------
# Mulberry32 PRNG — matches JS implementation exactly
# ---------------------------------------------------------------------------

def mulberry32_factory(seed: int):
    """Returns a callable PRNG matching the JS mulberry32 function."""
    state = [seed & 0xFFFFFFFF]

    def _next() -> float:
        a = state[0]
        a = (a + 0x6D2B79F5) & 0xFFFFFFFF
        state[0] = a
        # JS: let t = Math.imul(a ^ a >>> 15, 1 | a)
        t = (_imul(a ^ (a >> 15), 1 | a)) & 0xFFFFFFFF
        # t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t
        t = (t + _imul(t ^ (t >> 7), 61 | t) ^ t) & 0xFFFFFFFF
        return ((t ^ (t >> 14)) & 0xFFFFFFFF) / 4294967296

    return _next


def _imul(a: int, b: int) -> int:
    """32-bit integer multiplication (matches Math.imul)."""
    a &= 0xFFFFFFFF
    b &= 0xFFFFFFFF
    result = (a * b) & 0xFFFFFFFF
    # Sign-extend to match JS signed 32-bit
    if result >= 0x80000000:
        result -= 0x100000000
    return result


# ---------------------------------------------------------------------------
# Run ID & timestamps
# ---------------------------------------------------------------------------

def create_run_id() -> str:
    ts = format(int(time.time() * 1000), "x")
    rand = format(random.randint(0, 10**9 - 1), "x")
    return f"run_{ts}_{rand}"


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


# ---------------------------------------------------------------------------
# Clinical JSON serialization (matches JS safeJsonStringify: sorted keys)
# ---------------------------------------------------------------------------

def safe_json_stringify(obj: Any) -> str:
    """Mirrors JS safeJsonStringify — sorted keys, 2-space indent."""
    return json.dumps(obj, sort_keys=True, indent=2, ensure_ascii=False)


# ---------------------------------------------------------------------------
# Clinical record normalization
# ---------------------------------------------------------------------------

VALID_SPECIMEN = {"BLOOD", "URINE", "SWAB", "SALIVA", "PLASMA"}
VALID_STATUS = {"RECEIVED", "IN_PROGRESS", "REPORTED"}
VALID_UNIT = {"MG/DL", "MMOL/L", "IU/L", "CELLS/µL"}


def _safe_upper(s: str) -> str:
    """Uppercase ASCII chars only — matches JS V8 toUpperCase() for non-ASCII like µ."""
    return "".join(c.upper() if c.isascii() else c for c in s)


def normalize_record(r: dict, source: str = "json") -> dict:
    """Normalize a raw dict into the clinical schema."""
    raw_value = r.get("value", None)
    if isinstance(raw_value, (int, float)):
        value = float(raw_value)
    else:
        try:
            value = float(raw_value) if raw_value not in (None, "") else float("nan")
        except (TypeError, ValueError):
            value = float("nan")

    return {
        "id": str(r.get("id", "") or "").strip(),
        "patientId": str(r.get("patientId", "") or "").strip(),
        "specimenType": _safe_upper(str(r.get("specimenType", "") or "").strip()),
        "status": _safe_upper(str(r.get("status", "") or "").strip()),
        "value": value,
        "unit": _safe_upper(str(r.get("unit", "") or "").strip()),
        "collectedAt": str(r.get("collectedAt", "") or "").strip(),
        "accession": _safe_upper(str(r.get("accession", "") or "").strip()) if r.get("accession") is not None else "",
        "source": str(r.get("source", source)).lower(),
    }


# ---------------------------------------------------------------------------
# Parsing
# ---------------------------------------------------------------------------

def parse_json(text: str) -> dict:
    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        return {"error": f"E010 JSON parse error: {e}"}
    if not isinstance(data, list):
        return {"error": "JSON must be an array of clinical sample records."}
    records = [normalize_record(d, source="json") for d in data]
    return {"records": records}


def parse_xml(text: str) -> dict:
    try:
        root = ET.fromstring(text)
    except XmlParseError as e:
        return {"error": f"E009 XML parse error: {e}"}

    # Support both <samples><sample>... and root IS <samples>
    if root.tag == "samples":
        nodes = list(root.findall("sample"))
    else:
        nodes = list(root.findall(".//sample"))

    if not nodes:
        return {"error": "XML must contain <samples><sample>..</sample></samples>."}

    def g(node, tag):
        el = node.find(tag)
        return el.text if el is not None and el.text else ""

    records = []
    for x in nodes:
        records.append(normalize_record({
            "id": g(x, "id"),
            "patientId": g(x, "patientId"),
            "specimenType": g(x, "specimenType"),
            "status": g(x, "status"),
            "value": g(x, "value"),
            "unit": g(x, "unit"),
            "collectedAt": g(x, "collectedAt"),
            "accession": g(x, "accession"),
            "source": "xml",
        }))
    return {"records": records}


# ---------------------------------------------------------------------------
# Validation helpers
# ---------------------------------------------------------------------------

_ISO_DATE_RE = re.compile(
    r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2}(\.\d+)?)?Z$"
)
_ID_RE = re.compile(r"^[A-Za-z0-9\-_]{4,40}$")
_ACC_RE = re.compile(r"^[A-Z0-9\-]{8,30}$")


def is_iso_date(s: str) -> bool:
    return bool(_ISO_DATE_RE.match(s))


def id_pattern(s: str) -> bool:
    return bool(_ID_RE.match(s))


def accession_pattern(s: str) -> bool:
    return s == "" or bool(_ACC_RE.match(s))


ERROR_BOOK: dict[str, dict] = {
    "E001": {
        "title": "Missing Required Field",
        "fix": [
            "Identify the missing field.",
            "Ensure source systems populate it (LIS/LIMS).",
            "If unavailable, quarantine or enrich upstream.",
            "Re-run intake after correction.",
        ],
    },
    "E002": {
        "title": "Invalid Enumeration",
        "fix": [
            "Compare value to allowed list (specimenType/status/unit).",
            "Correct mapping in source or extend enum after review.",
            "Re-run validation.",
        ],
    },
    "E003": {
        "title": "Out-of-Range Value",
        "fix": [
            "Verify biological thresholds and units.",
            "Check unit conversions.",
            "Correct anomalous values or quarantine.",
        ],
    },
    "E004": {
        "title": "Chronology Violation",
        "fix": [
            "Sort samples by collectedAt.",
            "Ensure timestamps are not in the future.",
            "Re-intake after ordering fixes.",
        ],
    },
    "E005": {
        "title": "Plausibility Failure",
        "fix": [
            "Check clinical rules (e.g., REPORTED must have valid value).",
            "Review specimen/unit pairing.",
            "Fix data or quarantine.",
        ],
    },
    "E006": {
        "title": "Duplicate Detected",
        "fix": [
            "Use id+accession as a natural key.",
            "Deduplicate upstream.",
            "Keep first occurrence, quarantine duplicates.",
        ],
    },
    "E007": {
        "title": "Format Check Failed",
        "fix": [
            "Use ISO-8601 timestamp in collectedAt.",
            "Ensure id/accession match regex.",
            "Correct formatting upstream.",
        ],
    },
    "E009": {
        "title": "XML Parse Error",
        "fix": [
            "Validate XML structure.",
            "Fix closing tags & nesting.",
            "Re-submit.",
        ],
    },
    "E010": {
        "title": "JSON Parse Error",
        "fix": [
            "Validate JSON syntax.",
            "Remove trailing commas.",
            "Re-submit.",
        ],
    },
}


# ---------------------------------------------------------------------------
# Validation engine
# ---------------------------------------------------------------------------

def validate_records(records: list[dict], state: "CLSDWState") -> dict:
    valid = []
    quarantine_bin = []
    seen_key: set[str] = set()

    now_ms = int(time.time() * 1000)
    three_years_ago = now_ms - (1000 * 60 * 60 * 24 * 365 * 3)
    last_ts = -float("inf")

    required_fields = ["id", "patientId", "specimenType", "status", "value", "unit", "collectedAt"]

    for idx, r in enumerate(records):
        record_id = r["id"] if r["id"] else f"row_{idx+1}"

        def add_err(code, message, field):
            state.errors.append({"idx": idx, "id": record_id, "code": code, "message": message, "field": field})
            state.metrics["errorByCode"][code] = state.metrics["errorByCode"].get(code, 0) + 1

        # E001 — Required fields
        for f in required_fields:
            val = r.get(f)
            missing = (
                val is None
                or val == ""
                or (f == "value" and (isinstance(val, float) and math.isnan(val)))
            )
            if missing:
                add_err("E001", f"Required field '{f}' is missing", f)

        # E002 — Enumerations
        if r["specimenType"] and r["specimenType"] not in VALID_SPECIMEN:
            add_err("E002", f"Invalid specimenType '{r['specimenType']}'", "specimenType")
        if r["status"] and r["status"] not in VALID_STATUS:
            add_err("E002", f"Invalid status '{r['status']}'", "status")
        if r["unit"] and r["unit"] not in VALID_UNIT:
            add_err("E002", f"Invalid unit '{r['unit']}'", "unit")

        # E003 — Value range
        v = r["value"]
        if isinstance(v, float) and not math.isnan(v):
            if v < 0:
                add_err("E003", f"Value cannot be negative: {v}", "value")
            if v > 1_000_000:
                add_err("E003", f"Value out of range: {v}", "value")

        # E005 — REPORTED plausibility (mirrors JS condition exactly)
        # JS: if (r.status === 'REPORTED' && !(typeof r.value === 'number') || Number.isNaN(r.value))
        # Due to JS operator precedence this is: (status=REPORTED AND NOT number) OR isNaN
        is_nan_val = isinstance(r["value"], float) and math.isnan(r["value"])
        is_number = isinstance(r["value"], (int, float))
        if (r["status"] == "REPORTED" and not is_number) or is_nan_val:
            add_err("E005", "REPORTED requires a numeric value", "value")

        # E007 — Format checks
        if r["id"] and not id_pattern(r["id"]):
            add_err("E007", "Invalid id format", "id")
        if r["accession"] and not accession_pattern(r["accession"]):
            add_err("E007", "Invalid accession format", "accession")
        if r["collectedAt"] and not is_iso_date(r["collectedAt"]):
            add_err("E007", "Invalid ISO timestamp (collectedAt)", "collectedAt")

        # E004 + E003 — Timestamp checks
        if is_iso_date(r["collectedAt"]):
            try:
                dt = datetime.fromisoformat(r["collectedAt"].replace("Z", "+00:00"))
                t_ms = int(dt.timestamp() * 1000)
                if t_ms > now_ms:
                    add_err("E004", "collectedAt cannot be in the future", "collectedAt")
                if t_ms < three_years_ago:
                    add_err("E003", "collectedAt older than 3 years", "collectedAt")
                if t_ms < last_ts:
                    add_err("E004", "Dataset chronology must be non-decreasing", "collectedAt")
                last_ts = max(last_ts, float(t_ms))
            except (ValueError, OverflowError):
                add_err("E007", "Unparseable collectedAt", "collectedAt")

        # E006 — Duplicate check
        dedup_key = f"{r['id']}::{r['accession'] or ''}"
        if dedup_key in seen_key:
            add_err("E006", "Duplicate id+accession", "id/accession")
        else:
            seen_key.add(dedup_key)

        # Per-record audit checksum
        checksum = crc32_hex(safe_json_stringify(r))
        _log_audit(state, "validate:item", "ok", r["id"], f"preCRC={checksum}")

        # Categorise: valid vs quarantine
        had_errors = any(e["id"] == record_id and e["idx"] == idx for e in state.errors)
        if had_errors:
            quarantine_bin.append({"record": r, "reason": "Validation failure", "code": "E005"})
        else:
            valid.append(r)

    return {"valid": valid, "errors": state.errors, "quarantine": quarantine_bin}


# ---------------------------------------------------------------------------
# Processing
# ---------------------------------------------------------------------------

def process_records(state: "CLSDWState") -> list[dict]:
    out = []
    for r in state.valid_records:
        if "µL" in r["unit"]:
            category = "HEMATOLOGY"
        elif r["specimenType"] == "SWAB":
            category = "MICROBIOLOGY"
        else:
            category = "CHEMISTRY"

        processed = {**r, "processedAt": now_iso(), "normalizedValue": float(r["value"]), "category": category}
        checksum = crc32_hex(safe_json_stringify(processed))
        _log_audit(state, "process:item", "ok", r["id"], f"postCRC={checksum}")
        out.append(processed)

    state.processed = out
    _log_audit(state, "process", "-", "-", f"Processed {len(out)} records")
    return out


# ---------------------------------------------------------------------------
# Reconciliation
# ---------------------------------------------------------------------------

def reconcile_records(state: "CLSDWState", sla_ms: int = 1500) -> list[dict]:
    acks = []
    state.metrics["acked"] = 0
    state.metrics["slaBreaches"] = 0
    state.metrics["ackDelays"] = []

    for r in state.processed:
        seed = crc32(r["id"]) & 0xFFFFFFFF
        rand = mulberry32_factory(seed)
        delay = 100 + int(rand() * 2400)   # 100..2500ms
        ok = rand() > 0.12                  # ~88% success
        ack_code = 200 if ok else 500
        sla = delay <= sla_ms

        state.metrics["ackDelays"].append(delay)
        if ok:
            state.metrics["acked"] += 1
        if not sla:
            state.metrics["slaBreaches"] += 1

        acks.append({"id": r["id"], "ok": ok, "ackCode": ack_code, "delay": delay, "sla": sla})
        _log_audit(
            state, "reconcile:item",
            "ok" if ok else "error",
            r["id"],
            f"ack={ack_code} delay={delay}ms sla={'met' if sla else 'breach'}"
        )

    state.acks = acks
    _log_audit(
        state, "reconcile", "-", "-",
        f"ACKed={state.metrics['acked']} SLA breaches={state.metrics['slaBreaches']}"
    )
    return acks


# ---------------------------------------------------------------------------
# Audit
# ---------------------------------------------------------------------------

def _log_audit(state: "CLSDWState", stage: str, status: str, record_id: str, notes: str = "") -> None:
    entry = {
        "time": now_iso(),
        "runId": state.run_id,
        "stage": stage,
        "status": status,
        "recordId": record_id,
        "checksum": crc32_hex(f"{state.run_id}|{stage}|{record_id}|{notes}"),
        "notes": notes,
    }
    state.audit.append(entry)


def audit_to_csv(state: "CLSDWState") -> str:
    buf = io.StringIO()
    writer = csv.writer(buf, quoting=csv.QUOTE_ALL)
    writer.writerow(["time", "runId", "stage", "status", "recordId", "checksum", "notes"])
    for a in state.audit:
        writer.writerow([
            a["time"], a["runId"], a["stage"], a["status"],
            a["recordId"], a["checksum"], a["notes"].replace("\n", " "),
        ])
    return buf.getvalue()


# ---------------------------------------------------------------------------
# Dataset serialization helpers
# ---------------------------------------------------------------------------

def records_to_xml(records: list[dict]) -> str:
    def esc(s):
        return (str(s or "")
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;"))

    rows = []
    for r in records:
        rows.append(
            f"  <sample>\n"
            f"    <id>{esc(r['id'])}</id>\n"
            f"    <patientId>{esc(r['patientId'])}</patientId>\n"
            f"    <specimenType>{esc(r['specimenType'])}</specimenType>\n"
            f"    <status>{esc(r['status'])}</status>\n"
            f"    <value>{float(r['value'])}</value>\n"
            f"    <unit>{esc(r['unit'])}</unit>\n"
            f"    <collectedAt>{esc(r['collectedAt'])}</collectedAt>\n"
            f"    <accession>{esc(r['accession'])}</accession>\n"
            f"  </sample>"
        )
    return "<samples>\n" + "\n".join(rows) + "\n</samples>\n"


# ---------------------------------------------------------------------------
# Session state container
# ---------------------------------------------------------------------------

class CLSDWState:
    """Holds all mutable state for one CLSDW session / run."""

    def __init__(self):
        self.run_id: str = create_run_id()
        self.raw_input: str = ""
        self.input_format: str = "json"
        self.records: list[dict] = []
        self.valid_records: list[dict] = []
        self.quarantined: list[dict] = []
        self.errors: list[dict] = []
        self.processed: list[dict] = []
        self.acks: list[dict] = []
        self.audit: list[dict] = []
        self.metrics: dict = {
            "total": 0,
            "valid": 0,
            "errors": 0,
            "quarantine": 0,
            "acked": 0,
            "slaBreaches": 0,
            "errorByCode": {},
            "ackDelays": [],
        }

    def reset(self):
        self.__init__()

    def to_summary(self) -> dict:
        return {
            "runId": self.run_id,
            "total": self.metrics["total"],
            "valid": self.metrics["valid"],
            "errors": self.metrics["errors"],
            "quarantine": self.metrics["quarantine"],
            "acked": self.metrics["acked"],
            "slaBreaches": self.metrics["slaBreaches"],
            "errorByCode": self.metrics["errorByCode"],
            "ackDelays": self.metrics["ackDelays"],
        }


# ---------------------------------------------------------------------------
# High-level orchestration (mirrors JS intakeAndValidate)
# ---------------------------------------------------------------------------

def intake_and_validate(raw: str, fmt: str, state: CLSDWState) -> dict:
    """Full intake + validation pipeline. Resets state then populates it."""
    state.run_id = create_run_id()
    state.raw_input = raw
    state.input_format = fmt
    state.records = []
    state.valid_records = []
    state.quarantined = []
    state.errors = []
    state.processed = []
    state.acks = []
    state.audit = []
    state.metrics = {
        "total": 0, "valid": 0, "errors": 0, "quarantine": 0,
        "acked": 0, "slaBreaches": 0, "errorByCode": {}, "ackDelays": [],
    }

    parsed = parse_xml(raw) if fmt == "xml" else parse_json(raw)
    if "error" in parsed:
        _log_audit(state, "intake", "-", "error", parsed["error"])
        state.metrics["errors"] = 1
        return {"ok": False, "message": parsed["error"]}

    state.records = parsed["records"]
    state.metrics["total"] = len(state.records)
    _log_audit(state, "intake", "-", "ok", f"Ingested {len(state.records)} records via {fmt}")

    vres = validate_records(state.records, state)
    state.valid_records = vres["valid"]
    state.errors = vres["errors"]
    state.quarantined = vres["quarantine"]
    state.metrics["valid"] = len(state.valid_records)
    state.metrics["errors"] = len(state.errors)
    state.metrics["quarantine"] = len(state.quarantined)

    _log_audit(
        state, "validate", "-", "ok",
        f"Valid={state.metrics['valid']} Errors={state.metrics['errors']} Quarantine={state.metrics['quarantine']}"
    )

    return {
        "ok": True,
        "message": (
            f"Ingested {len(state.records)} records. "
            f"Valid: {len(state.valid_records)}. "
            f"Errors: {len(state.errors)}. "
            f"Quarantine: {len(state.quarantined)}."
        ),
    }
