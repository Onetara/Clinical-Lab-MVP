# CLSDW Python Backend

**Clinical Lab & Sample Data Workflows — Python/FastAPI Backend**
*Logic-complete backend for the CLSDW frontend (mirrors app.js by Stacy Toriola)*

---

## What's included

| File | Purpose |
|------|---------|
| `clsdw_core.py` | All business logic — CRC32, Mulberry32 PRNG, normalization, validation (E001–E010), processing, reconciliation, audit |
| `main.py` | FastAPI REST API — exposes every workflow operation as an HTTP endpoint |
| `test_clsdw.py` | 105 pytest tests — unit, integration, end-to-end, API |
| `requirements.txt` | Pinned Python dependencies |

---

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/health` | Health check |
| GET | `/playbooks` | All error-code playbooks (static) |
| POST | `/intake` | Ingest + validate JSON or XML dataset → returns `run_id` |
| GET | `/validate/{run_id}` | Validation results (errors, quarantine, KPIs) |
| POST | `/process/{run_id}` | Transform valid records (category, postCRC) |
| POST | `/reconcile/{run_id}?sla_ms=1500` | Simulate LIS/LIMS ACKs with SLA |
| GET | `/audit/{run_id}` | Full audit trail (JSON) |
| GET | `/audit/{run_id}/csv` | Export audit as CSV download |
| GET | `/dashboard/{run_id}` | Dashboard metrics |
| POST | `/new_entry/{run_id}` | Add one record and re-validate |
| GET | `/dataset/{run_id}` | Current dataset as JSON |
| GET | `/dataset/{run_id}/xml` | Current dataset as XML |
| POST | `/pipeline` | Full pipeline in one call (intake→validate→process→reconcile) |

Interactive docs auto-generated at: `http://127.0.0.1:8000/docs`

---

## Step-by-Step Setup on Windows 11

### Prerequisites (already installed per your setup)
- Python 3.10+ (verify: `python --version`)
- pip (verify: `pip --version`)
- A terminal — PowerShell, Windows Terminal, or CMD all work

---

### Step 1 — Open a terminal in the project folder

```powershell
# Navigate to wherever you extracted the zip
cd C:\path\to\clsdw_backend
```

---

### Step 2 — Create and activate a virtual environment

```powershell
# Create the venv (only needed once)
python -m venv .venv

# Activate it (every new terminal session)
.venv\Scripts\activate
```

You'll see `(.venv)` prepend your prompt when active.

> **Troubleshooting:** If you get "running scripts is disabled", run this once as Administrator:
> ```powershell
> Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
> ```

---

### Step 3 — Install dependencies

```powershell
pip install -r requirements.txt
```

Expected output ends with something like:
```
Successfully installed fastapi-0.115.12 uvicorn-0.34.3 ...
```

---

### Step 4 — Run the tests

```powershell
python -m pytest test_clsdw.py -v
```

Expected: `105 passed` (takes ~1 second).

For a compact summary instead:
```powershell
python -m pytest test_clsdw.py --tb=short -q
```

---

### Step 5 — Start the API server

```powershell
uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

You should see:
```
INFO:     Uvicorn running on http://127.0.0.1:8000 (Press CTRL+C to quit)
INFO:     Started reloader process
INFO:     Application startup complete.
```

`--reload` enables hot-reload on file save (dev mode). Remove it for production.

---

### Step 6 — Explore the interactive API docs

Open your browser and go to:

```
http://127.0.0.1:8000/docs
```

This opens Swagger UI — you can run every endpoint directly from the browser without any extra tool.

Alternatively, the ReDoc view is at:
```
http://127.0.0.1:8000/redoc
```

---

### Step 7 — Try a quick end-to-end test with curl (optional)

Open a *second* terminal (with the venv activated) while the server is running:

```powershell
# Health check
curl http://127.0.0.1:8000/health

# Full pipeline with example JSON (inline — PowerShell escape)
$body = '{
  "format": "json",
  "data": "[{\"id\":\"SMP-1001\",\"patientId\":\"PAT-001\",\"specimenType\":\"BLOOD\",\"status\":\"RECEIVED\",\"value\":85.2,\"unit\":\"MG/DL\",\"collectedAt\":\"2026-01-15T09:00:00Z\",\"accession\":\"ACC-2026-0001\"}]"
}'
curl -X POST http://127.0.0.1:8000/pipeline `
     -H "Content-Type: application/json" `
     -d $body
```

Or use the Swagger UI at `/docs` which is much easier for exploratory testing.

---

### Step 8 — Serve the frontend alongside the backend (optional)

The original `index.html` / `styles.css` / `app.js` are self-contained and work without the backend. To serve them from the same origin (useful if you integrate the API calls):

```powershell
# From the folder containing index.html, in a separate terminal:
python -m http.server 5500
```

Frontend: `http://127.0.0.1:5500`
Backend: `http://127.0.0.1:8000`

---

## Using the API — Workflow walkthrough

### Option A: Step-by-step (mirrors frontend tabs)

```
POST /intake       → get run_id
GET  /validate/{run_id}
POST /process/{run_id}
POST /reconcile/{run_id}?sla_ms=1500
GET  /audit/{run_id}
GET  /dashboard/{run_id}
GET  /audit/{run_id}/csv    ← download
```

### Option B: One-shot pipeline

```
POST /pipeline     → everything in one call, same run_id back
```

### Request format for `/intake` and `/pipeline`

```json
{
  "format": "json",
  "data": "[{\"id\":\"SMP-1001\", ...}]"
}
```

Or for XML:
```json
{
  "format": "xml",
  "data": "<samples><sample>...</sample></samples>"
}
```

---

## Technical notes

### Why this matches the JS exactly

| Concern | JS | Python |
|---------|----|----|
| CRC32 | IEEE 802.3, `^(-1)` init/final | Same polynomial + same init/final |
| PRNG | Mulberry32 with `Math.imul` | `_imul()` replicates 32-bit signed multiplication |
| Unit uppercasing | `'µ'.toUpperCase() === 'µ'` in V8 | `_safe_upper()` only uppercases ASCII chars |
| JSON key sort | `Object.keys(obj).sort()` | `json.dumps(..., sort_keys=True)` |
| Accession regex | `/^[A-Z0-9\-]{8,30}$/` | `^[A-Z0-9\-]{8,30}$` |
| ID regex | `/^[A-Za-z0-9\-_]{4,40}$/` | Same |

### Session model
Sessions are held in memory (`_sessions` dict). Each `POST /intake` creates a new session identified by `run_id`. Sessions are pruned (oldest first) when the store exceeds 500 entries. For production, replace with Redis or a database.

---

## Running in production (quick guide)

```powershell
# Install production ASGI server
pip install gunicorn

# Run with multiple workers (Windows: use uvicorn workers only)
uvicorn main:app --host 0.0.0.0 --port 8000 --workers 4
```

For Windows production deployments, Uvicorn directly (without gunicorn) is recommended since gunicorn's worker management is Unix-native.
