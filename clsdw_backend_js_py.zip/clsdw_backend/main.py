"""
main.py — CLSDW FastAPI Backend
Exposes REST endpoints that mirror every operation in app.js.

Session model: each POST /intake creates a new run and returns a run_id.
Subsequent calls pass run_id in the path (or query param) to retrieve state.

Endpoints
─────────
POST   /intake                  intake + validate (JSON or XML body)
GET    /validate/{run_id}       validation results for a run
POST   /process/{run_id}        process valid records
POST   /reconcile/{run_id}      run reconciliation (optional ?sla_ms=)
GET    /audit/{run_id}          full audit trail (JSON)
GET    /audit/{run_id}/csv      export audit as CSV download
GET    /dashboard/{run_id}      dashboard metrics
GET    /playbooks               error-code playbooks
POST   /new_entry/{run_id}      add a single new record and re-validate
GET    /dataset/{run_id}        current dataset as JSON
GET    /dataset/{run_id}/xml    current dataset as XML
GET    /health                  health check
"""

from __future__ import annotations

import json
import uuid
from typing import Any, Optional

from fastapi import FastAPI, HTTPException, Query, Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, PlainTextResponse, Response
from pydantic import BaseModel, Field

from clsdw_core import (
    CLSDWState,
    ERROR_BOOK,
    intake_and_validate,
    normalize_record,
    process_records,
    reconcile_records,
    audit_to_csv,
    records_to_xml,
    safe_json_stringify,
    parse_json,
    parse_xml,
    create_run_id,
)

# ---------------------------------------------------------------------------
# App setup
# ---------------------------------------------------------------------------

app = FastAPI(
    title="CLSDW — Clinical Lab & Sample Data Workflows API",
    description="Python backend for the CLSDW frontend (mirrors app.js logic)",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],     # tighten for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory session store  { run_id: CLSDWState }
_sessions: dict[str, CLSDWState] = {}

MAX_SESSIONS = 500   # prune oldest sessions beyond this


def _get_session(run_id: str) -> CLSDWState:
    if run_id not in _sessions:
        raise HTTPException(status_code=404, detail=f"Run '{run_id}' not found. Call POST /intake first.")
    return _sessions[run_id]


def _prune_sessions():
    if len(_sessions) > MAX_SESSIONS:
        oldest = list(_sessions.keys())[0]
        del _sessions[oldest]


# ---------------------------------------------------------------------------
# Pydantic models
# ---------------------------------------------------------------------------

class IntakeRequest(BaseModel):
    format: str = Field("json", description="'json' or 'xml'")
    data: str = Field(..., description="Raw JSON array or XML string")


class NewEntryRequest(BaseModel):
    id: str = ""
    patientId: str = ""
    specimenType: str = "BLOOD"
    status: str = "RECEIVED"
    value: Optional[float] = None
    unit: str = "MG/DL"
    collectedAt: str = ""
    accession: str = ""


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

@app.get("/health", tags=["Meta"])
def health():
    return {"status": "ok", "service": "CLSDW Python Backend", "sessions": len(_sessions)}


# ---------------------------------------------------------------------------
# Playbooks (static, no session needed)
# ---------------------------------------------------------------------------

@app.get("/playbooks", tags=["Playbooks"])
def get_playbooks():
    """Return all error-code playbooks."""
    return ERROR_BOOK


# ---------------------------------------------------------------------------
# Intake
# ---------------------------------------------------------------------------

@app.post("/intake", tags=["Workflow"])
def intake(req: IntakeRequest):
    """
    Ingest and validate a clinical dataset (JSON array or XML).
    Returns a run_id for subsequent calls.
    """
    fmt = req.format.strip().lower()
    if fmt not in ("json", "xml"):
        raise HTTPException(status_code=422, detail="format must be 'json' or 'xml'")

    state = CLSDWState()
    result = intake_and_validate(req.data, fmt, state)

    _prune_sessions()
    _sessions[state.run_id] = state

    return {
        "runId": state.run_id,
        "ok": result["ok"],
        "message": result["message"],
        "summary": state.to_summary(),
    }


# ---------------------------------------------------------------------------
# Validate
# ---------------------------------------------------------------------------

@app.get("/validate/{run_id}", tags=["Workflow"])
def get_validation(run_id: str):
    """Return validation results for a run."""
    state = _get_session(run_id)
    return {
        "runId": run_id,
        "metrics": {
            "total": state.metrics["total"],
            "valid": state.metrics["valid"],
            "errors": state.metrics["errors"],
            "quarantine": state.metrics["quarantine"],
        },
        "errors": state.errors,
        "quarantined": state.quarantined,
        "errorBook": {
            code: ERROR_BOOK.get(code, {}) for code in state.metrics.get("errorByCode", {})
        },
    }


# ---------------------------------------------------------------------------
# Process
# ---------------------------------------------------------------------------

@app.post("/process/{run_id}", tags=["Workflow"])
def process(run_id: str):
    """Transform/enrich valid records. Assigns category and postCRC checksum."""
    state = _get_session(run_id)
    if not state.valid_records:
        raise HTTPException(status_code=400, detail="No valid records to process. Run intake first.")
    processed = process_records(state)
    return {
        "runId": run_id,
        "processedCount": len(processed),
        "records": processed,
    }


# ---------------------------------------------------------------------------
# Reconcile
# ---------------------------------------------------------------------------

@app.post("/reconcile/{run_id}", tags=["Workflow"])
def reconcile(
    run_id: str,
    sla_ms: int = Query(1500, ge=100, description="SLA threshold in milliseconds"),
):
    """
    Simulate downstream ACKs (LIS/LIMS) with SLA enforcement.
    Deterministic: same run_id + sla_ms always yields same results.
    """
    state = _get_session(run_id)
    if not state.processed:
        raise HTTPException(
            status_code=400,
            detail="No processed records. Call POST /process/{run_id} first.",
        )
    acks = reconcile_records(state, sla_ms)
    return {
        "runId": run_id,
        "slaMs": sla_ms,
        "acked": state.metrics["acked"],
        "slaBreaches": state.metrics["slaBreaches"],
        "acks": acks,
    }


# ---------------------------------------------------------------------------
# Audit
# ---------------------------------------------------------------------------

@app.get("/audit/{run_id}", tags=["Audit"])
def get_audit(run_id: str):
    """Return full audit trail for a run."""
    state = _get_session(run_id)
    return {"runId": run_id, "audit": state.audit}


@app.get("/audit/{run_id}/csv", tags=["Audit"])
def export_audit_csv(run_id: str):
    """Download audit trail as CSV."""
    state = _get_session(run_id)
    csv_text = audit_to_csv(state)
    return Response(
        content=csv_text,
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="audit_{run_id}.csv"'},
    )


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------

@app.get("/dashboard/{run_id}", tags=["Dashboard"])
def get_dashboard(run_id: str):
    """Return dashboard metrics for a run."""
    state = _get_session(run_id)
    total = state.metrics["total"]
    err = state.metrics["errors"]
    breaches = state.metrics["slaBreaches"]
    ack_count = len(state.acks)

    error_rate = round((err / total) * 100) if total else 0
    sla_rate = round((breaches / ack_count) * 100) if ack_count else 0

    return {
        "runId": run_id,
        "errorRate": f"{error_rate}%",
        "slaBreachRate": f"{sla_rate}%",
        "quarantineSize": state.metrics["quarantine"],
        "throughput": total,
        "errorByCode": state.metrics["errorByCode"],
        "ackDelays": state.metrics["ackDelays"],
    }


# ---------------------------------------------------------------------------
# New Entry
# ---------------------------------------------------------------------------

@app.post("/new_entry/{run_id}", tags=["Workflow"])
def add_new_entry(run_id: str, entry: NewEntryRequest):
    """
    Add a single clinical sample record to the dataset, then re-run
    full intake+validation pipeline.
    """
    state = _get_session(run_id)

    # Build normalized record
    new_rec = normalize_record({
        "id": entry.id,
        "patientId": entry.patientId,
        "specimenType": entry.specimenType,
        "status": entry.status,
        "value": entry.value,
        "unit": entry.unit,
        "collectedAt": entry.collectedAt,
        "accession": entry.accession,
        "source": "json",
    })

    # Append to existing dataset
    current = state.records[:]
    current.append(new_rec)

    # Re-run intake pipeline (mirrors JS btnAddNew logic)
    result = intake_and_validate(safe_json_stringify(current), "json", state)

    return {
        "runId": state.run_id,
        "ok": result["ok"],
        "message": result["message"],
        "summary": state.to_summary(),
    }


# ---------------------------------------------------------------------------
# Dataset access
# ---------------------------------------------------------------------------

@app.get("/dataset/{run_id}", tags=["Dataset"])
def get_dataset_json(run_id: str):
    """Return current dataset as JSON."""
    state = _get_session(run_id)
    return {"runId": run_id, "format": "json", "records": state.records}


@app.get("/dataset/{run_id}/xml", tags=["Dataset"])
def get_dataset_xml(run_id: str):
    """Return current dataset as XML."""
    state = _get_session(run_id)
    xml_text = records_to_xml(state.records)
    return Response(content=xml_text, media_type="application/xml")


# ---------------------------------------------------------------------------
# Full pipeline convenience endpoint
# ---------------------------------------------------------------------------

@app.post("/pipeline", tags=["Workflow"])
def run_full_pipeline(
    req: IntakeRequest,
    sla_ms: int = Query(1500, ge=100, description="SLA threshold in milliseconds"),
):
    """
    Run the complete pipeline in one call:
      intake → validate → process → reconcile
    Returns all results plus run_id.
    """
    fmt = req.format.strip().lower()
    if fmt not in ("json", "xml"):
        raise HTTPException(status_code=422, detail="format must be 'json' or 'xml'")

    state = CLSDWState()
    iv = intake_and_validate(req.data, fmt, state)
    if not iv["ok"]:
        _prune_sessions()
        _sessions[state.run_id] = state
        return {
            "runId": state.run_id,
            "ok": False,
            "message": iv["message"],
            "stage": "intake",
        }

    processed = process_records(state)
    acks = reconcile_records(state, sla_ms)

    _prune_sessions()
    _sessions[state.run_id] = state

    total = state.metrics["total"]
    err_count = state.metrics["errors"]
    breaches = state.metrics["slaBreaches"]
    error_rate = round((err_count / total) * 100) if total else 0
    sla_rate = round((breaches / len(acks)) * 100) if acks else 0

    return {
        "runId": state.run_id,
        "ok": True,
        "message": iv["message"],
        "validation": {
            "total": state.metrics["total"],
            "valid": state.metrics["valid"],
            "errors": state.metrics["errors"],
            "quarantine": state.metrics["quarantine"],
            "errorList": state.errors,
            "quarantined": state.quarantined,
        },
        "processing": {
            "processedCount": len(processed),
        },
        "reconciliation": {
            "slaMs": sla_ms,
            "acked": state.metrics["acked"],
            "slaBreaches": state.metrics["slaBreaches"],
            "acks": acks,
        },
        "dashboard": {
            "errorRate": f"{error_rate}%",
            "slaBreachRate": f"{sla_rate}%",
            "quarantineSize": state.metrics["quarantine"],
            "throughput": total,
            "errorByCode": state.metrics["errorByCode"],
            "ackDelays": state.metrics["ackDelays"],
        },
    }
