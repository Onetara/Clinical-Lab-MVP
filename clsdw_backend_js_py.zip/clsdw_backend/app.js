/* Author: Stacy Toriola | Code Reviewer: Anthony O. */
// CLSDW – Clinical Lab & Sample Data Workflows
// Frontend wired to Python/FastAPI backend at API_BASE.
// All computation (validation, CRC32, processing, reconciliation, audit) is
// performed by the backend. The frontend owns only: rendering, UI state,
// chart drawing, editor beautify, file load, and tab navigation.

/* ===========================
   Backend Config
   =========================== */
const API_BASE = 'http://127.0.0.1:8000';

/* ===========================
   Global State
   Populated entirely from API responses — never computed in the browser.
   =========================== */
const STCDP = (() => {
  const state = {
    runId: null,            // assigned by backend on intake
    inputFormat: 'json',
    records: [],            // from GET /dataset
    validRecords: [],       // derived: records minus quarantined
    quarantined: [],        // from GET /validate
    errors: [],             // from GET /validate
    processed: [],          // from POST /process
    acks: [],               // from POST /reconcile
    audit: [],              // from GET /audit
    metrics: {
      total: 0, valid: 0, errors: 0, quarantine: 0,
      acked: 0, slaBreaches: 0,
      errorByCode: {},
      ackDelays: [],
    },
    ui: { dashAnimEnabled: true }
  };
  return state;
})();

/* ===========================
   Utilities (pure client-side)
   =========================== */
function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, ch => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  }[ch]));
}
function safeJsonStringify(obj) {
  try { return JSON.stringify(obj, null, 2); }
  catch { return JSON.stringify(obj); }
}
function download(filename, text, type = 'text/plain') {
  const blob = new Blob([text], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

/* ===========================
   Button loading state helpers
   =========================== */
function btnLoading(btn, on) {
  if (!btn) return;
  btn.classList.toggle('is-loading', on);
  btn.disabled = on;
}

/* ===========================
   API status banner
   =========================== */
function showBanner(msg, type = 'error') {
  const banner = document.getElementById('apiStatusBanner');
  const text   = document.getElementById('apiStatusText');
  banner.className = `stcdp-api-banner stcdp-api-banner--${type}`;
  text.textContent = msg;
  banner.classList.remove('stcdp-hidden');
}
function hideBanner() {
  document.getElementById('apiStatusBanner').classList.add('stcdp-hidden');
}
function setSummary(elId, msg, isError = false) {
  const el = document.getElementById(elId);
  if (!el) return;
  el.textContent = msg;
  el.className = 'stcdp-summary' + (isError ? ' is-error' : ' is-ok');
}

/* ===========================
   API helpers
   =========================== */
async function apiFetch(path, opts = {}) {
  const url = `${API_BASE}${path}`;
  const defaults = {
    headers: { 'Content-Type': 'application/json' },
  };
  const res = await fetch(url, { ...defaults, ...opts,
    headers: { ...defaults.headers, ...(opts.headers || {}) }
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    const detail = body?.detail || `HTTP ${res.status}`;
    throw new Error(detail);
  }
  return res.json();
}

/* Health-check: called on init and on retry button */
async function checkBackend() {
  try {
    await apiFetch('/health');
    hideBanner();
    return true;
  } catch {
    showBanner('⚠ Python backend unreachable at ' + API_BASE + ' — start it with: uvicorn main:app --reload', 'error');
    return false;
  }
}

/* ===========================
   Core workflow: API calls that populate STCDP
   =========================== */

/** POST /intake — resets all state, populates metrics + errors + quarantine */
async function apiIntake(raw, format) {
  const data = await apiFetch('/intake', {
    method: 'POST',
    body: JSON.stringify({ format, data: raw }),
  });

  STCDP.runId   = data.runId;
  STCDP.inputFormat = format;
  // Clear derived state from any previous run
  STCDP.records      = [];
  STCDP.validRecords = [];
  STCDP.processed    = [];
  STCDP.acks         = [];
  STCDP.audit        = [];

  const s = data.summary;
  STCDP.metrics.total      = s.total;
  STCDP.metrics.valid      = s.valid;
  STCDP.metrics.errors     = s.errors;
  STCDP.metrics.quarantine = s.quarantine;
  STCDP.metrics.errorByCode = s.errorByCode || {};
  STCDP.metrics.ackDelays  = [];
  STCDP.metrics.acked      = 0;
  STCDP.metrics.slaBreaches = 0;

  // Fetch full validation detail (errors + quarantine lists)
  await apiLoadValidation();
  // Fetch dataset so editor/download work
  await apiLoadDataset();
  // Fetch audit
  await apiLoadAudit();

  return data;
}

/** GET /validate/{run_id} — loads errors and quarantined lists */
async function apiLoadValidation() {
  if (!STCDP.runId) return;
  const data = await apiFetch(`/validate/${STCDP.runId}`);
  STCDP.errors      = data.errors      || [];
  STCDP.quarantined = data.quarantined || [];
  STCDP.metrics.total      = data.metrics.total;
  STCDP.metrics.valid      = data.metrics.valid;
  STCDP.metrics.errors     = data.metrics.errors;
  STCDP.metrics.quarantine = data.metrics.quarantine;
}

/** GET /dataset/{run_id} — loads records array */
async function apiLoadDataset() {
  if (!STCDP.runId) return;
  const data = await apiFetch(`/dataset/${STCDP.runId}`);
  STCDP.records = data.records || [];
}

/** GET /audit/{run_id} — loads audit log */
async function apiLoadAudit() {
  if (!STCDP.runId) return;
  const data = await apiFetch(`/audit/${STCDP.runId}`);
  STCDP.audit = data.audit || [];
}

/** POST /process/{run_id} — transforms valid records */
async function apiProcess() {
  if (!STCDP.runId) throw new Error('No active run. Run Intake first.');
  const data = await apiFetch(`/process/${STCDP.runId}`, { method: 'POST' });
  STCDP.processed = data.records || [];
  await apiLoadAudit();
  return data.processedCount;
}

/** POST /reconcile/{run_id} — simulates ACKs */
async function apiReconcile(slaMs) {
  if (!STCDP.runId) throw new Error('No active run. Run Intake first.');
  const data = await apiFetch(`/reconcile/${STCDP.runId}?sla_ms=${slaMs}`, { method: 'POST' });
  STCDP.acks = data.acks || [];
  STCDP.metrics.acked       = data.acked;
  STCDP.metrics.slaBreaches = data.slaBreaches;
  STCDP.metrics.ackDelays   = STCDP.acks.map(a => a.delay);
  await apiLoadAudit();
  // refresh dashboard metrics from backend
  const dash = await apiFetch(`/dashboard/${STCDP.runId}`);
  STCDP.metrics.errorByCode = dash.errorByCode || {};
  return STCDP.acks.length;
}

/** POST /new_entry/{run_id} — adds one record and re-runs intake pipeline */
async function apiNewEntry(entry) {
  if (!STCDP.runId) throw new Error('No active run. Run Intake first.');
  const data = await apiFetch(`/new_entry/${STCDP.runId}`, {
    method: 'POST',
    body: JSON.stringify(entry),
  });
  // Re-sync all state after mutation
  STCDP.runId = data.runId;  // run_id may change because intake is re-run
  const s = data.summary;
  STCDP.metrics.total      = s.total;
  STCDP.metrics.valid      = s.valid;
  STCDP.metrics.errors     = s.errors;
  STCDP.metrics.quarantine = s.quarantine;
  STCDP.metrics.errorByCode = s.errorByCode || {};
  STCDP.metrics.ackDelays  = [];
  STCDP.metrics.acked      = 0;
  STCDP.metrics.slaBreaches = 0;
  STCDP.processed = [];
  STCDP.acks      = [];
  await apiLoadValidation();
  await apiLoadDataset();
  await apiLoadAudit();
  return data;
}

/* ===========================
   Editor helpers
   These call the API to get the canonical dataset representation.
   =========================== */
async function editorShowCurrent(fmt) {
  if (!STCDP.runId) return { ok: false, text: '' };
  if (fmt === 'xml') {
    const res = await fetch(`${API_BASE}/dataset/${STCDP.runId}/xml`);
    const text = await res.text();
    return { ok: true, text };
  } else {
    const data = await apiFetch(`/dataset/${STCDP.runId}`);
    return { ok: true, text: JSON.stringify(data.records, null, 2) };
  }
}

/* ===========================
   Rendering
   Identical to the original — reads from STCDP which is now API-populated.
   =========================== */
function setText(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

function renderValidation() {
  setText('kpiTotal',     STCDP.metrics.total);
  setText('kpiValid',     STCDP.metrics.valid);
  setText('kpiErrors',    STCDP.metrics.errors);
  setText('kpiQuarantine',STCDP.metrics.quarantine);

  // Errors table
  const tbody = document.getElementById('tblErrors');
  tbody.innerHTML = '';
  let row = 1;
  for (const e of STCDP.errors) {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${row++}</td>
      <td><code class="stcdp-chip">${escapeHtml(e.id)}</code></td>
      <td><button type="button" class="stcdp-btn stcdp-btn--ghost stcdp-btn--tiny" data-playbook="${e.code}">${e.code}</button></td>
      <td>${escapeHtml(e.message)}</td>
      <td>${escapeHtml(e.field || '')}</td>
      <td><span class="stcdp-chip">${escapeHtml(ERROR_BOOK[e.code]?.title || 'See playbook')}</span></td>`;
    tbody.appendChild(tr);
  }

  // Quarantine table
  const tq = document.getElementById('tblQuarantine');
  tq.innerHTML = '';
  let qn = 1;
  for (const q of STCDP.quarantined) {
    const sample = JSON.stringify(q.record, null, 0).slice(0, 180).replace(/\n/g, ' ');
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${qn++}</td>
      <td><code class="stcdp-chip">${escapeHtml(q.record.id)}</code></td>
      <td>${escapeHtml(q.reason)} (${q.code})</td>
      <td><code>${escapeHtml(sample)}${sample.length >= 180 ? '…' : ''}</code></td>`;
    tq.appendChild(tr);
  }
}

function renderProcessSummary(count) {
  const el = document.getElementById('processSummary');
  el.textContent = `Processed ${count} record${count !== 1 ? 's' : ''}.`;
}

function renderReconcile() {
  setText('kpiAck', STCDP.metrics.acked);
  setText('kpiSla', STCDP.metrics.slaBreaches);

  const tbody = document.getElementById('tblAcks');
  tbody.innerHTML = '';
  let i = 1;
  for (const a of STCDP.acks) {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${i++}</td>
      <td><code class="stcdp-chip">${escapeHtml(a.id)}</code></td>
      <td>${a.ok ? '<span class="stcdp-ok">OK</span>' : '<span class="stcdp-bad">FAILED</span>'}</td>
      <td>${a.ackCode}</td>
      <td>${a.delay}</td>
      <td>${a.sla ? '<span class="stcdp-ok">MET</span>' : '<span class="stcdp-bad">BREACH</span>'}</td>`;
    tbody.appendChild(tr);
  }
}

function renderAudit() {
  const tbody = document.getElementById('tblAudit');
  tbody.innerHTML = '';
  let i = 1;
  for (const a of STCDP.audit) {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${i++}</td>
      <td>${escapeHtml(a.time)}</td>
      <td><code class="stcdp-chip">${escapeHtml(a.runId)}</code></td>
      <td>${escapeHtml(a.stage)}</td>
      <td><code>${escapeHtml(a.recordId || '-')}</code></td>
      <td>${escapeHtml(a.status)}</td>
      <td><code>${escapeHtml(a.checksum)}</code></td>
      <td>${escapeHtml(a.notes)}</td>`;
    tbody.appendChild(tr);
  }
}

function renderDashboard() {
  const total    = STCDP.metrics.total;
  const err      = STCDP.metrics.errors;
  const breaches = STCDP.metrics.slaBreaches;

  const errorRate = total ? Math.round((err / total) * 100) : 0;
  const slaRate   = STCDP.acks.length ? Math.round((breaches / STCDP.acks.length) * 100) : 0;

  setText('metricErrorRate',  `${errorRate}%`);
  setText('metricSlaRate',    `${slaRate}%`);
  setText('metricQuarantine', String(STCDP.metrics.quarantine));
  setText('metricThroughput', String(total));

  drawErrorBars('chartErrors',        STCDP.metrics.errorByCode);
  drawDelayHistogram('chartAckDelays', STCDP.metrics.ackDelays);
}

/* Charts — unchanged from original */
function drawErrorBars(canvasId, codeCounts) {
  const c = document.getElementById(canvasId);
  if (!c) return;
  const ctx = c.getContext('2d');
  ctx.clearRect(0, 0, c.width, c.height);
  const entries = Object.entries(codeCounts);
  if (!entries.length) return;

  const max  = Math.max(...entries.map(([, v]) => v));
  const barW = Math.max(24, Math.floor((c.width - 40) / entries.length) - 10);
  let x = 20;
  entries.forEach(([code, val]) => {
    const h = Math.round((val / max) * (c.height - 40));
    ctx.fillStyle = '#4cc9f0';
    ctx.fillRect(x, c.height - 20 - h, barW, h);
    ctx.strokeStyle = '#314257'; ctx.lineWidth = 1;
    ctx.strokeRect(x, c.height - 20 - h, barW, h);
    ctx.fillStyle = '#a8b0bf'; ctx.font = '12px system-ui';
    ctx.fillText(code, x, c.height - 4);
    x += barW + 10;
  });
}

function drawDelayHistogram(canvasId, delays) {
  const c = document.getElementById(canvasId);
  if (!c) return;
  const ctx = c.getContext('2d');
  ctx.clearRect(0, 0, c.width, c.height);
  if (!delays.length) return;

  const maxDelay = Math.max(...delays);
  const buckets  = Math.ceil(maxDelay / 200);
  const counts   = new Array(buckets).fill(0);
  delays.forEach(d => { counts[Math.min(buckets - 1, Math.floor(d / 200))]++; });

  const max  = Math.max(...counts);
  const barW = Math.max(18, Math.floor((c.width - 40) / buckets) - 6);
  let x = 20;
  for (let i = 0; i < buckets; i++) {
    const h = Math.round((counts[i] / max) * (c.height - 40));
    ctx.fillStyle = '#80ffdb';
    ctx.fillRect(x, c.height - 20 - h, barW, h);
    ctx.strokeStyle = '#2a6f5a';
    ctx.strokeRect(x, c.height - 20 - h, barW, h);
    ctx.fillStyle = '#a8b0bf'; ctx.font = '11px system-ui';
    ctx.fillText(`${i * 200}`, x, c.height - 4);
    x += barW + 6;
  }
}

/* ===========================
   Playbooks
   Loaded from backend on init, or falls back to bundled ERROR_BOOK.
   =========================== */

// Bundled copy so playbooks work even offline / before first API call
const ERROR_BOOK = Object.freeze({
  E001: { title: 'Missing Required Field',
    fix: ['Identify the missing field.',
          'Ensure source systems populate it (LIS/LIMS).',
          'If unavailable, quarantine or enrich upstream.',
          'Re-run intake after correction.'] },
  E002: { title: 'Invalid Enumeration',
    fix: ['Compare value to allowed list (specimenType/status/unit).',
          'Correct mapping in source or extend enum after review.',
          'Re-run validation.'] },
  E003: { title: 'Out-of-Range Value',
    fix: ['Verify biological thresholds and units.',
          'Check unit conversions.',
          'Correct anomalous values or quarantine.'] },
  E004: { title: 'Chronology Violation',
    fix: ['Sort samples by collectedAt.',
          'Ensure timestamps are not in the future.',
          'Re-intake after ordering fixes.'] },
  E005: { title: 'Plausibility Failure',
    fix: ['Check clinical rules (e.g., REPORTED must have valid value).',
          'Review specimen/unit pairing.',
          'Fix data or quarantine.'] },
  E006: { title: 'Duplicate Detected',
    fix: ['Use id+accession as a natural key.',
          'Deduplicate upstream.',
          'Keep first occurrence, quarantine duplicates.'] },
  E007: { title: 'Format Check Failed',
    fix: ['Use ISO-8601 timestamp in collectedAt.',
          'Ensure id/accession match regex.',
          'Correct formatting upstream.'] },
  E009: { title: 'XML Parse Error',
    fix: ['Validate XML structure.',
          'Fix closing tags & nesting.',
          'Re-submit.'] },
  E010: { title: 'JSON Parse Error',
    fix: ['Validate JSON syntax.',
          'Remove trailing commas.',
          'Re-submit.'] },
});

function renderPlaybooks(book) {
  // book may be the backend response or fallback to ERROR_BOOK
  const src = book || ERROR_BOOK;
  const host = document.getElementById('playbookList');
  host.innerHTML = '';
  Object.entries(src).forEach(([code, meta]) => {
    const det = document.createElement('details');
    det.id = `playbook-${code}`;
    const summary = document.createElement('summary');
    summary.innerHTML = `<strong>${code}</strong> — ${escapeHtml(meta.title)}`;
    det.appendChild(summary);
    const ol = document.createElement('ol');
    (meta.fix || []).forEach(step => {
      const li = document.createElement('li');
      li.textContent = step;
      ol.appendChild(li);
    });
    det.appendChild(ol);
    host.appendChild(det);
  });
}

/* ===========================
   Tab / navigation helpers
   =========================== */
function switchTab(target) {
  document.querySelectorAll('.stcdp-tab').forEach(b => b.classList.remove('is-active'));
  document.querySelectorAll('.stcdp-panel').forEach(p => p.classList.add('stcdp-hidden'));
  document.querySelector(`.stcdp-tab[data-tab="${target}"]`)?.classList.add('is-active');
  document.getElementById(`stcdp-panel-${target}`)?.classList.remove('stcdp-hidden');
}
function onClickPlaybook(e) {
  const code = e.target?.dataset?.playbook;
  if (!code) return;
  switchTab('playbooks');
  const d = document.getElementById(`playbook-${code}`);
  if (d) { d.open = true; d.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
}

/* ===========================
   Clinical Examples
   =========================== */
const JSON_EXAMPLE_TEXT = `[
  {"id":"SMP-1001","patientId":"PAT-001","specimenType":"BLOOD","status":"RECEIVED","value":85.2,"unit":"MG/DL","collectedAt":"2026-01-15T09:00:00Z","accession":"ACC-2026-0001"},
  {"id":"SMP-1002","patientId":"PAT-002","specimenType":"URINE","status":"IN_PROGRESS","value":6.5,"unit":"MMOL/L","collectedAt":"2026-01-15T09:05:00Z","accession":"ACC-2026-0002"},
  {"id":"SMP-1003","patientId":"PAT-003","specimenType":"SWAB","status":"REPORTED","value":1,"unit":"IU/L","collectedAt":"2026-01-15T09:10:00Z","accession":"ACC-2026-0003"},
  {"id":"SMP-1004","patientId":"PAT-004","specimenType":"SALIVA","status":"RECEIVED","value":0.8,"unit":"IU/L","collectedAt":"2026-01-15T09:12:00Z","accession":"ACC-2026-0004"},
  {"id":"SMP-1005","patientId":"PAT-005","specimenType":"PLASMA","status":"REPORTED","value":245,"unit":"MG/DL","collectedAt":"2026-01-15T09:15:00Z","accession":"ACC-2026-0005"},
  {"id":"SMP-1006","patientId":"PAT-006","specimenType":"BLOOD","status":"IN_PROGRESS","value":4.6,"unit":"MMOL/L","collectedAt":"2026-01-15T09:20:00Z","accession":"ACC-2026-0006"},
  {"id":"SMP-1007","patientId":"PAT-007","specimenType":"PLASMA","status":"RECEIVED","value":120,"unit":"MG/DL","collectedAt":"2026-01-15T09:25:00Z","accession":"ACC-2026-0007"},
  {"id":"SMP-1008","patientId":"PAT-008","specimenType":"URINE","status":"REPORTED","value":2.1,"unit":"MMOL/L","collectedAt":"2026-01-15T09:30:00Z","accession":"ACC-2026-0008"},
  {"id":"SMP-1009","patientId":"PAT-009","specimenType":"SWAB","status":"REPORTED","value":0,"unit":"IU/L","collectedAt":"2026-01-15T09:35:00Z","accession":"ACC-2026-0009"},
  {"id":"SMP-1010","patientId":"PAT-010","specimenType":"BLOOD","status":"IN_PROGRESS","value":4500,"unit":"CELLS/µL","collectedAt":"2026-01-15T09:40:00Z","accession":"ACC-2026-0010"},
  {"id":"bad id!","patientId":"PAT-011","specimenType":"PLASMA","status":"REPORTED","value":-3,"unit":"MG/DL","collectedAt":"2026-01-15T09:42:00Z","accession":"TOO-LONG-REF-123456-OVER"},
  {"id":"SMP-1002","patientId":"PAT-002","specimenType":"URINE","status":"RECEIVED","value":1.1,"unit":"XYZ","collectedAt":"2026-01-15T09:45:00Z","accession":"ACC-2026-0002"}
]`;

const XML_EXAMPLE_TEXT = `<samples>
  <sample>
    <id>SMP-2001</id><patientId>PAT-021</patientId><specimenType>BLOOD</specimenType>
    <status>RECEIVED</status><value>92.4</value><unit>MG/DL</unit>
    <collectedAt>2026-01-16T10:00:00Z</collectedAt><accession>ACC-2026-0101</accession>
  </sample>
  <sample>
    <id>SMP-2002</id><patientId>PAT-022</patientId><specimenType>URINE</specimenType>
    <status>IN_PROGRESS</status><value>4.2</value><unit>MMOL/L</unit>
    <collectedAt>2026-01-16T10:05:00Z</collectedAt><accession>ACC-2026-0102</accession>
  </sample>
  <sample>
    <id>SMP-2003</id><patientId>PAT-023</patientId><specimenType>SWAB</specimenType>
    <status>REPORTED</status><value>1</value><unit>IU/L</unit>
    <collectedAt>2026-01-16T10:06:00Z</collectedAt><accession>ACC-2026-0103</accession>
  </sample>
  <sample>
    <id>SMP-2004</id><patientId>PAT-024</patientId><specimenType>SALIVA</specimenType>
    <status>RECEIVED</status><value>0.7</value><unit>IU/L</unit>
    <collectedAt>2026-01-16T10:08:00Z</collectedAt><accession>ACC-2026-0104</accession>
  </sample>
  <sample>
    <id>SMP-2005</id><patientId>PAT-025</patientId><specimenType>PLASMA</specimenType>
    <status>REPORTED</status><value>210</value><unit>MG/DL</unit>
    <collectedAt>2026-01-16T10:10:00Z</collectedAt><accession>ACC-2026-0105</accession>
  </sample>
  <sample>
    <id>SMP-2006</id><patientId>PAT-026</patientId><specimenType>BLOOD</specimenType>
    <status>IN_PROGRESS</status><value>5.2</value><unit>MMOL/L</unit>
    <collectedAt>2026-01-16T10:15:00Z</collectedAt><accession>ACC-2026-0106</accession>
  </sample>
  <sample>
    <id>SMP-2007</id><patientId>PAT-027</patientId><specimenType>PLASMA</specimenType>
    <status>RECEIVED</status><value>130</value><unit>MG/DL</unit>
    <collectedAt>2026-01-16T10:20:00Z</collectedAt><accession>ACC-2026-0107</accession>
  </sample>
  <sample>
    <id>SMP-2008</id><patientId>PAT-028</patientId><specimenType>URINE</specimenType>
    <status>REPORTED</status><value>1.9</value><unit>MMOL/L</unit>
    <collectedAt>2026-01-16T10:25:00Z</collectedAt><accession>ACC-2026-0108</accession>
  </sample>
  <sample>
    <id>SMP-2009</id><patientId>PAT-029</patientId><specimenType>SWAB</specimenType>
    <status>REPORTED</status><value>0</value><unit>IU/L</unit>
    <collectedAt>2026-01-16T10:30:00Z</collectedAt><accession>ACC-2026-0109</accession>
  </sample>
  <sample>
    <id>SMP-2010</id><patientId>PAT-030</patientId><specimenType>BLOOD</specimenType>
    <status>IN_PROGRESS</status><value>5200</value><unit>CELLS/µL</unit>
    <collectedAt>2026-01-16T10:35:00Z</collectedAt><accession>ACC-2026-0110</accession>
  </sample>
  <sample>
    <id>bad id!</id><patientId>PAT-031</patientId><specimenType>PLASMA</specimenType>
    <status>REPORTED</status><value>-2</value><unit>MG/DL</unit>
    <collectedAt>2027-05-01T00:00:00Z</collectedAt><accession>TOO-LONG-REF-123456-OVER</accession>
  </sample>
  <sample>
    <id>SMP-2002</id><patientId>PAT-022</patientId><specimenType>URINE</specimenType>
    <status>RECEIVED</status><value>1.1</value><unit>XYZ</unit>
    <collectedAt>2026-01-16T10:40:00Z</collectedAt><accession>ACC-2026-0102</accession>
  </sample>
</samples>`;

/* ===========================
   Initialization
   =========================== */
function init() {
  document.getElementById('year').textContent = new Date().getFullYear();

  // ── Tabs ────────────────────────────────────────────────────────────
  document.querySelectorAll('.stcdp-tab').forEach(btn => {
    btn.addEventListener('click', () => switchTab(btn.dataset.tab));
  });

  // ── Format radio ────────────────────────────────────────────────────
  document.querySelectorAll('input[name="format"]').forEach(r => {
    r.addEventListener('change', e => { STCDP.inputFormat = e.target.value; });
  });

  // ── Retry backend button ────────────────────────────────────────────
  document.getElementById('btnRetryApi').addEventListener('click', () => checkBackend());

  // ── Intake: load examples ───────────────────────────────────────────
  document.getElementById('btnLoadJson').addEventListener('click', () => {
    STCDP.inputFormat = 'json';
    document.querySelector('input[name="format"][value="json"]').checked = true;
    document.getElementById('inputData').value = JSON_EXAMPLE_TEXT;
  });
  document.getElementById('btnLoadXml').addEventListener('click', () => {
    STCDP.inputFormat = 'xml';
    document.querySelector('input[name="format"][value="xml"]').checked = true;
    document.getElementById('inputData').value = XML_EXAMPLE_TEXT;
  });
  document.getElementById('btnClear').addEventListener('click', () => {
    document.getElementById('inputData').value = '';
    document.getElementById('intakeSummary').textContent = '';
  });

  // ── Intake: submit ──────────────────────────────────────────────────
  document.getElementById('btnIntake').addEventListener('click', async () => {
    const raw = document.getElementById('inputData').value.trim();
    if (!raw) { setSummary('intakeSummary', 'Paste data first.', true); return; }
    const btn = document.getElementById('btnIntake');
    btnLoading(btn, true);
    hideBanner();
    try {
      const res = await apiIntake(raw, STCDP.inputFormat);
      setSummary('intakeSummary', res.message, !res.ok);
      renderValidation();
      renderAudit();
      renderDashboard();
      switchTab('validate');
    } catch (err) {
      showBanner('Intake error: ' + err.message);
      setSummary('intakeSummary', 'Intake failed: ' + err.message, true);
    } finally {
      btnLoading(btn, false);
    }
  });

  // ── Process ─────────────────────────────────────────────────────────
  document.getElementById('btnProcess').addEventListener('click', async () => {
    if (!STCDP.runId) { setSummary('processSummary', 'Run Intake first.', true); return; }
    const btn = document.getElementById('btnProcess');
    btnLoading(btn, true);
    try {
      const count = await apiProcess();
      renderProcessSummary(count);
      renderAudit();
      renderDashboard();
    } catch (err) {
      showBanner('Process error: ' + err.message);
      setSummary('processSummary', 'Process failed: ' + err.message, true);
    } finally {
      btnLoading(btn, false);
    }
  });

  // ── Reconcile ───────────────────────────────────────────────────────
  document.getElementById('btnReconcile').addEventListener('click', async () => {
    if (!STCDP.runId) { return; }
    const sla = Number(document.getElementById('slaMs').value) || 1500;
    const btn = document.getElementById('btnReconcile');
    btnLoading(btn, true);
    try {
      const n = await apiReconcile(sla);
      renderReconcile();
      renderAudit();
      renderDashboard();
      if (!n) showBanner('No processed records to reconcile. Run "Process" first.', 'warn');
    } catch (err) {
      showBanner('Reconcile error: ' + err.message);
    } finally {
      btnLoading(btn, false);
    }
  });

  // ── Audit: Export CSV (direct link to backend) ───────────────────────
  document.getElementById('btnExportAudit').addEventListener('click', () => {
    if (!STCDP.runId) { showBanner('No active run. Run Intake first.', 'warn'); return; }
    // Open the backend CSV endpoint directly — browser triggers download
    window.location.href = `${API_BASE}/audit/${STCDP.runId}/csv`;
  });

  // ── Audit: Copy JSON ─────────────────────────────────────────────────
  document.getElementById('btnCopyAudit').addEventListener('click', async () => {
    const text = safeJsonStringify(STCDP.audit);
    try {
      await navigator.clipboard.writeText(text);
      alert('Audit JSON copied to clipboard.');
    } catch {
      download(`audit_${STCDP.runId || 'export'}.json`, text, 'application/json');
    }
  });

  // ── Playbooks: render + click-to-jump ──────────────────────────────
  // Load from backend, fall back to bundled
  apiFetch('/playbooks')
    .then(book => renderPlaybooks(book))
    .catch(() => renderPlaybooks(null));
  document.getElementById('tblErrors').addEventListener('click', onClickPlaybook);

  // ── Editor: Show Current ────────────────────────────────────────────
  document.getElementById('btnShowCurrent').addEventListener('click', async () => {
    if (!STCDP.runId) {
      document.getElementById('editorSummary').textContent = 'No active run. Run Intake first.';
      return;
    }
    const fmt = document.querySelector('input[name="editorFormat"]:checked').value;
    try {
      const { text } = await editorShowCurrent(fmt);
      document.getElementById('editorText').value = text;
      document.getElementById('editorSummary').textContent = `Rendered current dataset as ${fmt.toUpperCase()}.`;
    } catch (err) {
      document.getElementById('editorSummary').textContent = `Failed: ${err.message}`;
    }
  });

  // ── Editor: Beautify (pure client-side, no API call needed) ─────────
  document.getElementById('btnBeautify').addEventListener('click', () => {
    const fmt = document.querySelector('input[name="editorFormat"]:checked').value;
    const el  = document.getElementById('editorText');
    const raw = el.value.trim();
    try {
      if (fmt === 'json') {
        el.value = JSON.stringify(JSON.parse(raw), null, 2);
      } else {
        const parser = new DOMParser();
        const xml    = parser.parseFromString(raw, 'application/xml');
        if (xml.querySelector('parsererror')) throw new Error('XML parse error');
        el.value = new XMLSerializer().serializeToString(xml);
      }
      document.getElementById('editorSummary').textContent = 'Beautified successfully.';
    } catch (e) {
      document.getElementById('editorSummary').textContent = `Beautify failed: ${e.message}`;
    }
  });

  // ── Editor: Load file ───────────────────────────────────────────────
  document.getElementById('filePicker').addEventListener('change', ev => {
    const file = ev.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const text = String(reader.result || '');
      document.getElementById('editorText').value = text;
      const isXml = /\.xml$/i.test(file.name);
      document.querySelector(`input[name="editorFormat"][value="${isXml ? 'xml' : 'json'}"]`).checked = true;
      document.getElementById('editorSummary').textContent = `Loaded ${file.name} (${text.length} bytes)`;
    };
    reader.readAsText(file);
  });

  // ── Editor: Apply (sends to backend, same as Intake) ────────────────
  document.getElementById('btnApplyEditor').addEventListener('click', async () => {
    const fmt = document.querySelector('input[name="editorFormat"]:checked').value;
    const raw = document.getElementById('editorText').value.trim();
    if (!raw) {
      document.getElementById('editorSummary').textContent = 'Nothing to apply.';
      return;
    }
    const btn = document.getElementById('btnApplyEditor');
    btnLoading(btn, true);
    try {
      const res = await apiIntake(raw, fmt);
      document.getElementById('editorSummary').textContent =
        res.ok ? `Applied: ${res.message}` : `Apply failed: ${res.message}`;
      renderValidation();
      renderAudit();
      renderDashboard();
      switchTab('validate');
    } catch (err) {
      document.getElementById('editorSummary').textContent = `Apply failed: ${err.message}`;
      showBanner('Apply error: ' + err.message);
    } finally {
      btnLoading(btn, false);
    }
  });

  // ── Editor: Download (uses backend canonical form) ──────────────────
  document.getElementById('btnDownloadCurrent').addEventListener('click', async () => {
    if (!STCDP.runId) {
      document.getElementById('editorSummary').textContent = 'No active run. Run Intake first.';
      return;
    }
    const fmt = document.querySelector('input[name="editorFormat"]:checked').value;
    try {
      const { text } = await editorShowCurrent(fmt);
      const ext  = fmt === 'xml' ? 'xml' : 'json';
      const mime = fmt === 'xml' ? 'application/xml' : 'application/json';
      download(`clsdw_dataset_${STCDP.runId}.${ext}`, text, mime);
    } catch (err) {
      document.getElementById('editorSummary').textContent = `Download failed: ${err.message}`;
    }
  });

  // ── New Entry ────────────────────────────────────────────────────────
  document.getElementById('btnAddNew').addEventListener('click', async () => {
    const dtLocal = document.getElementById('newCollected').value;
    const collectedAt = dtLocal
      ? new Date(dtLocal).toISOString().replace(/\.\d{3}Z$/, 'Z')
      : '';

    const entry = {
      id:           document.getElementById('newId').value.trim(),
      patientId:    document.getElementById('newPatientId').value.trim(),
      specimenType: document.getElementById('newSpecimen').value,
      status:       document.getElementById('newStatus').value,
      value:        Number(document.getElementById('newValue').value) || null,
      unit:         document.getElementById('newUnit').value,
      collectedAt,
      accession:    document.getElementById('newAccession').value.trim().toUpperCase(),
    };

    if (!STCDP.runId) {
      setSummary('newSummary', 'Run Intake first before adding entries.', true);
      return;
    }

    const btn = document.getElementById('btnAddNew');
    btnLoading(btn, true);
    try {
      const res = await apiNewEntry(entry);
      setSummary('newSummary',
        res.ok ? `Added & validated. ${res.message}` : `Add failed: ${res.message}`,
        !res.ok
      );
      renderValidation();
      renderAudit();
      renderDashboard();
      switchTab('validate');
    } catch (err) {
      showBanner('New entry error: ' + err.message);
      setSummary('newSummary', 'Add failed: ' + err.message, true);
    } finally {
      btnLoading(btn, false);
    }
  });

  // ── Dashboard animation toggle ───────────────────────────────────────
  const animToggle = document.getElementById('toggleDashAnim');
  const animHost   = document.getElementById('dashboardAnimHost');
  const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  STCDP.ui.dashAnimEnabled = !prefersReduced;
  animToggle.checked = STCDP.ui.dashAnimEnabled;
  if (!STCDP.ui.dashAnimEnabled) animHost.classList.remove('is-animated');
  animToggle.addEventListener('change', () => {
    STCDP.ui.dashAnimEnabled = !!animToggle.checked;
    animHost.classList.toggle('is-animated', STCDP.ui.dashAnimEnabled);
  });

  // ── Initial state ────────────────────────────────────────────────────
  switchTab('intake');
  checkBackend();  // probe backend; show banner if unreachable
}

document.addEventListener('DOMContentLoaded', init);

/* ===========================
   Notes
   - All computation delegated to Python backend (main.py / clsdw_core.py)
   - Frontend owns: rendering, charts, editor beautify, file load, tab nav
   - STCDP state populated entirely from API responses
   - CSP updated in index.html to allow connect-src to 127.0.0.1:8000
   - Backend health checked on load; sticky banner shown if unreachable
   - Loading spinners on all async buttons; errors surfaced inline + banner
   =========================== */
